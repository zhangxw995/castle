var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var connection = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"123",
    prot:3306,
    database:"pythonsql"
});

/* GET users listing. */
router.get('/query', function(req, res, next) {
  var sql="select * from miqilin";
  connection.query(sql,[],function (err, result) {
      if(err)console.log(err)
      res.send(result)
  })
});

module.exports = router;
